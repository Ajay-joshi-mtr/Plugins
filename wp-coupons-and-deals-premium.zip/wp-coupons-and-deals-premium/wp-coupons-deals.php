<?php

/**
 * Plugin Name: WP Coupons and Deals (Premium)
 * Plugin URI: https://wpcouponsdeals.com/
 * Version: 2.8.5
 * Description: Best WordPress Coupon Plugin. Generate more affiliate sales with coupon codes and deals.
 * Author: WP Coupons and Deals
 * Author URI: https://wpcouponsdeals.com/
 * Author Email: irayhan.asif@gmail.com
 * Text Domain: wpcd-coupon
 * License: GPLv2 or later
 *
 * @package wpcd_coupon
 * @author Imtiaz Rayhan
 */
// If accessed directly, exit.
if ( !defined( 'ABSPATH' ) ) {
    die;
}
/**
 * Loading translation.
 */

if ( !function_exists( 'wpcd_load_languages' ) ) {
    function wpcd_load_languages()
    {
        load_plugin_textdomain( 'wpcd-coupon', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
    }

} else {
    deactivate_plugins( plugin_basename( __FILE__ ) );
    wp_die( 'Please deactivate the free version of the plugin before activating the pro version.' );
}

add_action( 'plugins_loaded', 'wpcd_load_languages' );
// Loading SDK.
class FsNull {
    public function is_not_paying() {
        return false;
    }

    public function can_use_premium_code() {
        return true;
    }

    public function can_use_premium_code__premium_only() {
        return true;
    }

    public function is__premium_only() {
        return true;
    }
	    public function is_plan__premium_only() {
        return true;
    }
		    public function get_upgrade_url() {
        return false;
	    }
}
if ( !function_exists( 'wcad_fs' ) ) {
    /**
     * Configure freemius
     */
    function wcad_fs()
    {
        global  $wcad_fs ;
        
        if ( !isset( $wcad_fs ) ) {
            // Include Freemius SDK.
            require_once dirname( __FILE__ ) . '/includes/sdk/freemius/start.php';
            $wcad_fs = new FsNull();
        }
        
        return $wcad_fs;
    }
    
    // Init SDK.
    wcad_fs();
    // Signal that SDK was initiated.
    do_action( 'wcad_fs_loaded' );
}

// Requiring the main plugin file.
require_once dirname( __FILE__ ) . '/includes/main.php';
// Instantiating the main class plugin.
WPCD_Plugin::instance();
// Initialing hooks, functions, classes.
WPCD_Plugin::init();
register_activation_hook( __FILE__, array( 'WPCD_Plugin', 'wpcd_activate' ) );
register_deactivation_hook( __FILE__, array( 'WPCD_Plugin', 'wpcd_deactivate' ) );