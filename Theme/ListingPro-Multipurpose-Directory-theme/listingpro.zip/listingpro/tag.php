<?php get_header();?>
	<!--==================================Section Open=================================-->
	<section>
		<div class="container page-container-five">
			<div class="row">
				<?php get_template_part( 'loop', 'tags' ); ?>
			</div>
		</div>
	</section>
	<!--==================================Section Close=================================-->
<?php get_footer();?>