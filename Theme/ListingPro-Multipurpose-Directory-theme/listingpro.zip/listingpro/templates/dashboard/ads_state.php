<p id="reply-title" class="clarfix lp-general-section-title comment-reply-title active"> <?php echo esc_html__('ADS STATS', 'listingpro'); ?> <i class="fa fa-angle-down" aria-hidden="true"></i></p>
<div class="lp-ad-click-inner" id="lp-ad-click-inner">
	<div class="lp-ad-details-outer">
		<div class="lp-total-clicks">
			<div class="lp-total-clicks-inner">
				<h4><?php echo get_query_var('lptotalClicks'); ?></h4>
				<h5><?php echo esc_html__('Clicks', 'listingpro'); ?></h5>
			</div>
				
		</div>
		<p><?php echo esc_html__('Total Ads Clicks', 'listingpro'); ?></p>
		
	</div>
	
</div>	