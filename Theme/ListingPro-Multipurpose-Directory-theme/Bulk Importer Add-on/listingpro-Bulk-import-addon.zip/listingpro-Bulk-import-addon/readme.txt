=== Import Listings into Listingpro Theme ===

License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tested up to: 1.0.5
Stable tag: 1.0.0

Easily import property listings from any XML or CSV file to the Listingpro theme with the Listingpro Add-On for WP All Import.

== Description ==

The Listingpro Add-On for [WP All Import](http://wordpress.org/plugins/wp-all-import "WordPress XML & CSV Import") makes it easy to bulk import your property listings to the Listingpro theme in less than 10 minutes.

The left side shows all of the fields that you can import to and the right side displays a property listing from your XML/CSV file. Then you can simply drag & drop the data from your XML or CSV into the Listingpro fields to import it.

The importer is so intuitive it is almost like manually adding a property listing in Listingpro.