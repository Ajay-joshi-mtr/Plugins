<?php
/*
Plugin Name: WP All Import - Listingpro Add-On
Plugin URI: http://www.cridio.com
Description: Supporting imports into the Listingpro theme.
Version: 1.0.2
Author: Cridio team
*/


include "rapid-addon.php";

$listingpro_addon = new RapidAddon( 'Listingpro Add-On', 'listingpro_addon' );

$listingpro_addon->disable_default_images();

$listingpro_addon->import_images( 'listingpro_addon_gallery_images', 'Gallery Images' );
$listingpro_addon->import_images( 'listingpro_addon_logo_image', 'Listings Logo' );



//for logo
function listingpro_addon_logo_image( $post_id, $attachment_id, $image_filepath, $import_options ) {
	$image_attributes = wp_get_attachment_image_src( $attachment_id );
	$b_logo_url = $image_attributes[0];
	listing_set_metabox('business_logo', $b_logo_url, $post_id);
}

// for gallery
function listingpro_addon_gallery_images( $post_id, $attachment_id, $image_filepath, $import_options ) {
	$postMeta = get_post_meta( $post_id, 'gallery_image_ids', true );
	if(!empty($postMeta)){
		$postMeta .=','.$attachment_id;
		update_post_meta( $post_id, 'gallery_image_ids', $postMeta );
	}
	else{
		add_post_meta( $post_id, 'gallery_image_ids', $attachment_id ) || update_post_meta( $post_id, 'gallery_image_ids', $attachment_id );
	}
    
}

//$listingpro_addon->import_images( 'listingpro_addon_floorplan_images', 'Floor Plan Images' );

function listingpro_addon_floorplan_images( $post_id, $attachment_id, $image_filepath, $import_options ) {
    static $last_post_id, $fp_count;

    $fp_count = ($post_id === $last_post_id) ? $fp_count + 1 : 0;
    $fp_meta = get_post_meta( $post_id, 'floor_plans', true );
    $image = wp_get_attachment_image_src( $attachment_id, 'full' );
    if ( !is_array( $image ) ) return;
    $fp_meta[$fp_count]['fave_plan_image'] = $image[0];
    update_post_meta( $post_id, 'floor_plans', $fp_meta );
    $last_post_id = $post_id;
}

//$listingpro_addon->import_files( 'listingpro_addon_property_attachments', 'Property Attachments' );

function listingpro_addon_property_attachments( $post_id, $attachment_id, $image_filepath, $import_options ) {
    add_post_meta( $post_id, 'fave_attachments', $attachment_id ) || update_post_meta( $post_id, 'fave_attachments', $attachment_id );
}

/* for listngpro */
$listingpro_addon->add_field( 'tagline_text', 'Tagline Text', 'text', null, 'tagline_text' );
$listingpro_addon->add_field( 'gAddress', 'Google Address', 'text', null, 'gAddress' );
$listingpro_addon->add_field( 'latitude', 'Latitude', 'text', null, 'Latitude' );
$listingpro_addon->add_field( 'longitude', 'Longitude', 'text', null, 'Longitude' );
$listingpro_addon->add_field( 'phone', 'Phone', 'text', null, 'phone' );
$listingpro_addon->add_field( 'email', 'Email', 'text', null, 'email' );
$listingpro_addon->add_field( 'website', 'Website', 'text', null, 'website' );
$listingpro_addon->add_field( 'twitter', 'Twitter', 'text', null, 'twitter' );
$listingpro_addon->add_field( 'facebook', 'Facebook', 'text', null, 'facebook' );
$listingpro_addon->add_field( 'linkedin', 'Linkedin', 'text', null, 'linkedin' );
$listingpro_addon->add_field( 'google_plus', 'Google_plus', 'text', null, 'google_plus' );
$listingpro_addon->add_field( 'youtube', 'Youtube', 'text', null, 'youtube' );
$listingpro_addon->add_field( 'instagram', 'Instagram', 'text', null, 'instagram' );
$listingpro_addon->add_field( 'video', 'Youtube Video URL', 'text', null, 'video' );
//$listingpro_addon->add_field( 'gallery', 'Gallery ids', 'text', null, 'gallery' );
$listingpro_addon->add_field( 'price_status', 'Price Status', 'text', null, 'price_status' );
$listingpro_addon->add_field( 'Plan_id', 'Pricing Plan ID', 'text', null, 'Put Pricing plan id here' );
$listingpro_addon->add_field( 'list_price', 'Price From', 'text', null, 'list_price' );
$listingpro_addon->add_field( 'list_price_to', 'Price To', 'text', null, 'list_price_to' );
$listingpro_addon->add_field( 'claimed_section', 'Claime Status', 'text', null, 'claimed_section' );
$listingpro_addon->add_field( 'faq', 'Faq Question (seperate by pipe sign | )', 'text', null, 'Q1 | Q2 | Q3' );
$listingpro_addon->add_field( 'businesshours', 'Business Hours (Day,opentime,closetime)', 'text', null, 'Sunday,08:00,18:00| Monday,09:00,17:00 | Tuesday,09:00,15:00' );
$listingpro_addon->add_field( 'faqans', 'Faq Ans (seperate by pipe sign | )', 'text', null, 'ANS1 | ANS2 | ANS3' );
/* for listngpro */




$listingpro_addon->set_import_function( 'listingpro_addon_import' );

$listingpro_addon->admin_notice();
/* Check dependent plugins */
$listingpro_addon->admin_notice( 'Listingpro Add-on requires WP All Import <a href="http://www.wpallimport.com/order-now/?utm_source=free-plugin&utm_medium=dot-org&utm_campaign=listingpro" target="_blank">Pro</a> or <a href="http://wordpress.org/plugins/wp-all-import" target="_blank">Free</a>, and the <a href="https://themeforest.net/item/listingpro-multipurpose-directory-theme/19386460">Listingpro</a> theme.',  array('themes' => array("Listingpro")));

$listingpro_addon->run( array(
    "themes"     => array("Listingpro"),
    "post_types" => array("listing")
) );

function listingpro_addon_import( $post_id, $data, $import_options ) {

    global $listingpro_addon;

    // all fields except for slider and image fields
    $fields = array(
        'tagline_text',
        'gAddress',
        'latitude',
        'longitude',
        'phone',
        'email',
        'website',
        'twitter',
        'facebook',
        'linkedin',
        'google_plus',
        'youtube',
        'instagram',
        'video',
        'gallery',
        'price_status',
        'Plan_id',
        'list_price',
        'list_price_to',
        'claimed_section',
        'faq',
        'faqans',
        'businesshours',
 
    );
	
	
	$LPmeta = 'lp_listingpro_options';


    // image fields
    $image_fields = array(
        'fave_prop_slider_image',
        'fave_video_image',
    );

   

    $fields = array_merge( $fields);

    // update everything in fields arrays
	$myMeta = array();
	$myFaqs = array();
    foreach ( $fields as $field ) {

        if ( $listingpro_addon->can_update_meta( $field, $import_options ) ) {

            // Image fields
            if ( in_array( $field, $image_fields ) ) {
                if ( $listingpro_addon->can_update_image( $import_options ) ) {

                    $id = $data[$field]['attachment_id'];

                    if ( strlen( $id ) == 0 ) {
                        delete_post_meta( $post_id, $field );
                    } else {
                        update_post_meta( $post_id, $field, $id );
                    }

                }
            }elseif($field=="faq"){
				$myfaq = explode("|",$data[$field]);
				array_unshift($myfaq,"");
				unset($myfaq[0]);
				$myFaqs['faq'] = $myfaq;
			}
			elseif($field=="faqans"){
				$myfaqans = explode("|",$data[$field]);
				array_unshift($myfaqans,"");
				unset($myfaqans[0]);
				$myFaqs['faqans'] = $myfaqans;
			}elseif($field=="businesshours"){
				/* hours data */
				$hoursData =array();
				$completeString = $data[$field];
				if(!empty($completeString)){
					$stringArary = explode("|",$completeString);
					if(!empty($stringArary)){
						foreach($stringArary as $singleArray){
							$singleDayArray = explode(",",$singleArray);
							if(!empty($singleDayArray)){
								$day = $singleDayArray[0];
								$open = $singleDayArray[1];
								$close = $singleDayArray[2];
								if( !empty($open) && !empty($close) ){}else{
									$open = '';
									$close = '';
								}
									$hoursData[$day] = array(
										'open'=> $open,
										'close'=> $close,
									);
							}
						}
					}
				}
				
				
				if(!empty($hoursData)){
					//save data in post meta
					$myMeta['business_hours'] = $hoursData;
				}
				/* end hours data */
			} 			
            else {
					$myMeta[$field] = $data[$field];
            }
        }
    }
	if(!empty($myFaqs)){
		$myMeta['faqs'] = $myFaqs;
	}
	update_post_meta($post_id, $LPmeta, $myMeta);
	
    // clear image fields to override import settings
    $fields = array(
        'fave_attachments',
        'fave_property_images'
    );

    if ( $listingpro_addon->can_update_image( $import_options ) ) {

        foreach ( $fields as $field ) {

            delete_post_meta( $post_id, $field );

        }

    }

    // update agent, create a new one if not found
    $field = 'fave_agents';
    $post_type = 'listingpro_agent';

    if ( $listingpro_addon->can_update_meta( $field, $import_options ) ) {

        $post = get_page_by_title( $data[$field], 'OBJECT', $post_type );

        if ( !empty($post) ) {

            update_post_meta( $post_id, $field, $post->ID );

        } else {

            // insert title and attach to property
            $postarr = array(
                'post_content' => '',
                'post_name'    => $data[$field],
                'post_title'   => $data[$field],
                'post_type'    => $post_type,
                'post_status'  => 'publish',
                'post_excerpt' => ''
            );

            wp_insert_post( $postarr );

            $post = get_page_by_title( $data[$field], 'OBJECT', $post_type );

            update_post_meta( $post_id, $field, $post->ID );

        }
    }

    // update property location
    $field = 'fave_property_map_address';

    $address = $data[$field];

    $lat = $data['property_latitude'];

    $long = $data['property_longitude'];

    //  build search query
    if ( $data['location_settings'] == 'search_by_address' ) {

        $search = (!empty($address) ? 'address=' . rawurlencode( $address ) : null);

    } else {

        $search = (!empty($lat) && !empty($long) ? 'latlng=' . rawurlencode( $lat . ',' . $long ) : null);

    }

    // build api key
    if ( $data['location_settings'] == 'search_by_address' ) {

        if ( $data['address_geocode'] == 'address_google_developers' && !empty($data['address_google_developers_api_key']) ) {

            $api_key = '&key=' . $data['address_google_developers_api_key'];

        } elseif ( $data['address_geocode'] == 'address_google_for_work' && !empty($data['address_google_for_work_client_id']) && !empty($data['address_google_for_work_signature']) ) {

            $api_key = '&client=' . $data['address_google_for_work_client_id'] . '&signature=' . $data['address_google_for_work_signature'];

        }

    } else {

        if ( $data['coord_geocode'] == 'coord_google_developers' && !empty($data['coord_google_developers_api_key']) ) {

            $api_key = '&key=' . $data['coord_google_developers_api_key'];

        } elseif ( $data['coord_geocode'] == 'coord_google_for_work' && !empty($data['coord_google_for_work_client_id']) && !empty($data['coord_google_for_work_signature']) ) {

            $api_key = '&client=' . $data['coord_google_for_work_client_id'] . '&signature=' . $data['coord_google_for_work_signature'];

        }

    }

    // if all fields are updateable and $search has a value
    if ( $listingpro_addon->can_update_meta( $field, $import_options ) && $listingpro_addon->can_update_meta( 'fave_property_location', $import_options ) && !empty ($search) ) {

        // build $request_url for api call
        $request_url = 'https://maps.googleapis.com/maps/api/geocode/json?' . $search . $api_key;
        $curl = curl_init();

        curl_setopt( $curl, CURLOPT_URL, $request_url );
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );

        $listingpro_addon->log( '- Getting location data from Geocoding API: ' . $request_url );

        $json = curl_exec( $curl );
        curl_close( $curl );

        // parse api response
        if ( !empty($json) ) {

            $details = json_decode( $json, true );

            if ( $data['location_settings'] == 'search_by_address' ) {

                $lat = $details[results][0][geometry][location][lat];

                $long = $details[results][0][geometry][location][lng];

            } else {

                $address = $details[results][0][formatted_address];

            }

        }

    }

    // update location fields
    $fields = array(
        'fave_property_map_address'  => $address,
        'fave_property_location' => $lat . ',' . $long
    );

    $listingpro_addon->log( '- Updating location data' );

    foreach ( $fields as $key => $value ) {

        if ( $listingpro_addon->can_update_meta( $key, $import_options ) ) {

            update_post_meta( $post_id, $key, $value );

        }
    }
}

/*  */
function lp_update_features_taxonomy( $post_id ) {

	if ( get_post_type( $post_id ) == 'listing' ) {
		/* for features v.2 */
		$cat_term_list = wp_get_post_terms($post_id, 'listing-category', array("fields" => "all"));
		$feat_term_list = wp_get_post_terms($post_id, 'features', array("fields" => "all"));
		
		if(!empty($feat_term_list)){
			if(!empty($cat_term_list)){
				foreach($cat_term_list as $singlecatTerm){
					$featureaIDS = array();
					foreach($feat_term_list as $singlefeatTerm){
						$featureaIDS[] = $singlefeatTerm->term_id;
					}
					$existingFeatures = get_term_meta($singlecatTerm->term_id, 'lp_category_tags', true);
					if(!empty($existingFeatures)){
						$featureaIDS = array_merge($existingFeatures, $featureaIDS);
					}
					update_term_meta( $singlecatTerm->term_id, 'lp_category_tags', $featureaIDS );
				}
			}
		}
		/* end of features import */
	}
		
}

add_action('lp_saved_post', 'lp_update_features_taxonomy', 1, 1);