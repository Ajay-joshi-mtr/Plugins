jQuery( document ).ready( function ( $ ) {
	
} );

