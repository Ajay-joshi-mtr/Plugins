/**
 * NOO VC Admin Package.
 *
 * Javascript used in meta-boxes for Post, Page and Portfolio.
 *
 * @package    NOO Framework
 * @subpackage NOO VC Admin
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */
// =============================================================================

