<?php

require_once NOO_FRAMEWORK . '/add-ons/ziprecruiter/class-jobs-ziprecruiter.php';