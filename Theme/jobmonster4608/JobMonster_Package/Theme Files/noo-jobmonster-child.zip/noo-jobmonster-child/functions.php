<?php
/**
 * Theme functions for NOO JobMonster Child Theme.
 *
 * @package    NOO JobMonster Child Theme
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */
function noo_jobmonster_child_enqueue_styles() {
    wp_enqueue_style( 'noo-jobmonster-child-style', get_stylesheet_directory_uri() . '/style.css');
}
add_action( 'wp_enqueue_scripts', 'noo_jobmonster_child_enqueue_styles',99 );
