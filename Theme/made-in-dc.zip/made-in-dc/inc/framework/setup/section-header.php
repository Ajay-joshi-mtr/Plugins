<?php
Kirki::add_field( 'jackryan_customize', array(
    'type' => 'dimension',
    'settings' => 'header_height',
    'section' => 'header_settings',
    'label' => esc_html__( 'Header Height', 'jackryan' ),
    'description' => esc_html__( 'Select the height of the logo (default: 18px). For proportions, the width is set automatically', 'jackryan' ),
    'priority' => $priority++,
    'transport' => 'auto',
    'default' => '60px',
    'output'    => [
        [
            'element'  => ':root',
            'property' => '--main-header-height-md',
        ],
    ],
    'transport' => 'auto',
) );
Kirki::add_field( 'jackryan_customize', array(
    'type' => 'dimension',
    'settings' => 'logo_height',
    'section' => 'header_settings',
    'label' => esc_html__( 'Max Height of Logo Image', 'jackryan' ),
    'description' => esc_html__( 'Select the height of the logo (default: 18px). For proportions, the width is set automatically', 'jackryan' ),
    'priority' => $priority++,
    'transport' => 'auto',
    'default' => '18px',
    'output' => array(
        array(
            'element' => '.main-header__logo a, .main-header__logo svg, .main-header__logo img',
            'property' => 'height' 
        ) 
    ) 
) );
Kirki::add_field( 'jackryan_customize', array(
    'type' => 'dimension',
    'settings' => 'footer_logo_height',
    'section' => 'header_settings',
    'label' => esc_html__( 'Max Height of Footer Logo Image', 'jackryan' ),
    'description' => esc_html__( 'Select the height of the footer logo (default: 18px). For proportions, the width is set automatically', 'jackryan' ),
    'priority' => $priority++,
    'transport' => 'auto',
    'default' => '18px',
    'output' => array(
        array(
            'element' => '.ms-logo__default img',
            'property' => 'height' 
        ) 
    ) 
) );
Kirki::add_field('jackryan_customize', array(
    'section' => 'header_settings',
    'type' => 'image',
    'settings' => 'logo_light',
    'label' => esc_html__('Image Logo Light', 'jackryan'),
    'description' => esc_html__( 'Choose a light logo image to display for header', 'jackryan' ),
    'default' => $theme_path_images . 'logo_w.svg',
    'priority' => $priority++
));

Kirki::add_field('jackryan_customize', array(
    'section' => 'header_settings',
    'type' => 'image',
    'settings' => 'logo_dark',
    'label' => esc_html__('Image Logo Dark', 'jackryan'),
    'description' => esc_html__( 'Choose a dark logo image to display for header', 'jackryan' ),
    'default' => $theme_path_images . 'logo_d.svg',
    'priority' => $priority++
));