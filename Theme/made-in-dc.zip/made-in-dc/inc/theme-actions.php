<?php

/**
 * Register Sidebar.
 */
function jackryan_register_sidebar() {
	register_sidebar( 
		array(
			'name'          => esc_html__( 'Blog Sidebar', 'jackryan' ),
			'id'            => 'blog_sidebar',
			'before_widget' => '<aside id="%1$s" class="%2$s">',
			'after_widget'  => '</aside>',
			'before_title'  => '<div class="text-divider"><h5>',
			'after_title'   => '</h5></div>'
		)
	);
	register_sidebar( 
		array(
			'name'          => esc_html__( 'Socials', 'jackryan' ),
			'id'            => 'socials',
			'description'   => esc_html__( 'Socials Icons (footer and contact).', 'jackryan' ),
			'before_widget' => '<ul class="socials">',
			'after_widget'  => '</ul>',
			'before_title'  => '<h5 class="h5">',
			'after_title'   => '</h5>'
		)
	);
}
add_action( 'widgets_init', 'jackryan_register_sidebar' );

function hide_update_msg_non_admins(){
 if (current_user_can( 'manage_options' )) { // non-admin users
        echo '<style>.notice.is-dismissible[data-dismissible="dismiss-coblocks-21"] { display: none; } .blockgallery-notice {display: none; visibility: hidden;}</style>';
    }
}
add_action( 'admin_head', 'hide_update_msg_non_admins');

if ( ! function_exists( 'wp_body_open' ) ) {
        function wp_body_open() {
                do_action( 'wp_body_open' );
        }
}