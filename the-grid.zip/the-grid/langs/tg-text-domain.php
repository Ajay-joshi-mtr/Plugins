<?php
/* THIS IS A GENERATED FILE. DO NOT EDIT DIRECTLY. */
$generated_i18n_strings = array(
	// Reference: backend/assets/js/gutenberg/grid/index.js:15
	__( 'Display a grid.', 'tg-text-domain' ),

	// Reference: backend/assets/js/gutenberg/grid/index.js:19
	__( 'masonry', 'tg-text-domain' ),

	// Reference: backend/assets/js/gutenberg/grid/index.js:20
	__( 'layout', 'tg-text-domain' ),

	// Reference: backend/assets/js/gutenberg/grid/index.js:21
	__( 'grid', 'tg-text-domain' ),

	// Reference: backend/assets/js/gutenberg/grid/inspector.js:17
	__( 'Grid Settings', 'tg-text-domain' ),

	// Reference: backend/assets/js/gutenberg/grid/select.js:24
	__( 'Please, select a grid', 'tg-text-domain' )
);
/* THIS IS THE END OF THE GENERATED FILE */
